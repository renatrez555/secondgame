class_name KeyPickup
extends Area2D
## Ключ. Игрок касается - получает +1 ключ, ключ пропадает.

var key_value: int = 1
var is_collected: bool = false

@export var animated_sprite: AnimatedSprite2D
@export var collision_shape: CollisionShape2D


func _ready() -> void:
	collision_layer = 0              # сам ключ ни с чем физически не сталкивается
	collision_mask = 0xFFFFFFFF      # но "видит" объекты на всех слоях
	monitoring = true
	body_entered.connect(_on_body_entered)
	print("[КЛЮЧ] готов: ", name)


func _on_body_entered(body: Node2D) -> void:
	print("[КЛЮЧ] коснулось: ", body.name, " | это Player? ", body is Player)
	if body is Player and not is_collected:
		collect(body)


func collect(player: Player) -> void:
	is_collected = true
	if collision_shape:
		collision_shape.set_deferred("disabled", true)

	player.keys += key_value
	print("[КЛЮЧ] подобран. Ключей у игрока: ", player.keys)

	# Если есть анимация "collect" - проигрываем, иначе просто убираем ключ
	if animated_sprite and animated_sprite.sprite_frames \
			and animated_sprite.sprite_frames.has_animation("collect"):
		animated_sprite.play("collect")
		await animated_sprite.animation_finished

	queue_free()
