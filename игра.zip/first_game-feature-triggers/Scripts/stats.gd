class_name Stats
extends Node
## Компонент характеристик: здоровье, броня, выносливость.
## Добавь как дочерний узел к игроку/врагу и обращайся через $Stats.

signal health_changed(current: float, maximum: float)
signal stamina_changed(current: float, maximum: float)
signal armor_changed(value: float)
signal died

# --- Здоровье ---
@export var max_health: float = 100.0
# --- Броня ---
# Каждые 100 брони уменьшают урон вдвое: урон * 100 / (100 + броня)
@export var armor: float = 0.0
# --- Выносливость ---
@export var max_stamina: float = 100.0
@export var stamina_regen: float = 15.0        # единиц в секунду
@export var stamina_regen_delay: float = 1.0   # пауза после траты, сек

var health: float
var stamina: float
var _regen_timer: float = 0.0
var is_dead: bool = false


func _ready() -> void:
	health = max_health
	stamina = max_stamina
	health_changed.emit(health, max_health)
	stamina_changed.emit(stamina, max_stamina)
	armor_changed.emit(armor)


func _process(delta: float) -> void:
	# Восстановление выносливости после паузы
	if _regen_timer > 0.0:
		_regen_timer -= delta
	elif stamina < max_stamina and not is_dead:
		stamina = minf(stamina + stamina_regen * delta, max_stamina)
		stamina_changed.emit(stamina, max_stamina)


# ---------- ЗДОРОВЬЕ ----------
func take_damage(amount: float, ignore_armor: bool = false) -> void:
	if is_dead:
		return
	var final_damage := amount
	if not ignore_armor:
		final_damage = amount * 100.0 / (100.0 + armor)
	health = maxf(health - final_damage, 0.0)
	health_changed.emit(health, max_health)
	if health <= 0.0:
		is_dead = true
		died.emit()


func heal(amount: float) -> void:
	if is_dead:
		return
	health = minf(health + amount, max_health)
	health_changed.emit(health, max_health)


# ---------- БРОНЯ ----------
func set_armor(value: float) -> void:
	armor = maxf(value, 0.0)
	armor_changed.emit(armor)


func add_armor(value: float) -> void:
	set_armor(armor + value)


# ---------- ВЫНОСЛИВОСТЬ ----------
func has_stamina(amount: float) -> bool:
	return stamina >= amount


## Пытается потратить выносливость. Возвращает true, если хватило.
func use_stamina(amount: float) -> bool:
	if stamina < amount:
		return false
	stamina -= amount
	_regen_timer = stamina_regen_delay
	stamina_changed.emit(stamina, max_stamina)
	return true


## Для непрерывной траты (бег): передавай трату в секунду * delta.
func drain_stamina(amount: float) -> bool:
	return use_stamina(amount)
