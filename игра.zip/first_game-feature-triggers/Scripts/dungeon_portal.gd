class_name DungeonPortal
extends Area2D
## Портал-дверь. Игрок подходит и нажимает E. Рисуется кодом, сцена не нужна.
## kind = "enter" (вход в подземелье) или "exit" (выход из него).
## Начало координат - у ног, по центру двери.

signal activated(portal: DungeonPortal)

var kind: String = "enter"
var label_text: String = "Подземелье"
var door_size: Vector2 = Vector2(26.0, 38.0)
var color: Color = Color(0.35, 0.22, 0.5)

var _inside: bool = false


func _ready() -> void:
	collision_layer = 0
	collision_mask = 0xFFFFFFFF
	monitoring = true

	var shape := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = Vector2(door_size.x + 20.0, door_size.y + 10.0)
	shape.shape = rect
	shape.position = Vector2(0.0, -door_size.y * 0.5)
	add_child(shape)

	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	queue_redraw()


func _process(_delta: float) -> void:
	# Лёгкое мерцание портала
	queue_redraw()


func _on_body_entered(body: Node2D) -> void:
	if body.is_in_group("player"):
		_inside = true


func _on_body_exited(body: Node2D) -> void:
	if body.is_in_group("player"):
		_inside = false


func _unhandled_input(event: InputEvent) -> void:
	if not _inside:
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_E:
		activated.emit(self)


func _draw() -> void:
	var w := door_size.x
	var h := door_size.y
	var pulse := 0.5 + 0.5 * sin(Time.get_ticks_msec() * 0.004)

	# Рама, арка и тёмный проём
	draw_rect(Rect2(-w * 0.5 - 3.0, -h, w + 6.0, h), color.darkened(0.3))
	draw_circle(Vector2(0.0, -h), w * 0.5 + 3.0, color.darkened(0.3))
	draw_rect(Rect2(-w * 0.5, -h, w, h), Color(0.04, 0.03, 0.08))
	draw_circle(Vector2(0.0, -h), w * 0.5, Color(0.04, 0.03, 0.08))
	# Свечение внутри
	draw_rect(Rect2(-w * 0.35, -h * 0.85, w * 0.7, h * 0.85), Color(color, 0.25 + 0.2 * pulse))

	# Подпись и подсказка
	var font := ThemeDB.fallback_font
	var text := "[E] " + label_text if _inside else label_text
	draw_string(font, Vector2(-60.0, -h - w * 0.5 - 8.0), text, HORIZONTAL_ALIGNMENT_CENTER, 120.0, 11)
