class_name EnemyFactory
extends RefCounted
## Создаёт врагов кодом, сцены не нужны. diff - сложность: 0 лёгкие, 1 и больше сильнее.
## ground_pos - точка на поверхности земли, куда враг встаёт ногами.

static func walker(parent: Node, ground_pos: Vector2, diff: float, drop: PackedScene) -> Enemy:
	var e := Enemy.new()
	e.max_health = 22.0 * (1.0 + 0.5 * diff)
	e.contact_damage = 8.0 + 5.0 * diff
	e.move_speed = 45.0 + 12.0 * diff
	e.chase_speed = 80.0 + 22.0 * diff
	e.placeholder_color = Color(0.85, 0.25, 0.25)
	e.drop_scene = drop
	return _place(e, parent, ground_pos, Vector2(14.0, 14.0))


static func shooter(parent: Node, ground_pos: Vector2, diff: float, drop: PackedScene) -> ShooterEnemy:
	var e := ShooterEnemy.new()
	e.max_health = 18.0 * (1.0 + 0.5 * diff)
	e.contact_damage = 6.0 + 4.0 * diff
	e.move_speed = 30.0
	e.projectile_damage = 8.0 + 4.0 * diff
	e.shoot_interval = maxf(2.2 - 0.4 * diff, 0.9)
	e.placeholder_color = Color(0.60, 0.30, 0.85)
	e.drop_scene = drop
	_place(e, parent, ground_pos, Vector2(14.0, 16.0))
	return e


static func boss(parent: Node, ground_pos: Vector2, diff: float, drop: PackedScene, title: String) -> Boss:
	var b := Boss.new()
	b.boss_name = title
	b.max_health = 160.0 * (1.0 + 0.4 * diff)
	b.contact_damage = 16.0 + 4.0 * diff
	b.shot_damage = 9.0 + 3.0 * diff
	b.armor = 20.0 * diff
	b.activation_range = 320.0
	b.stomp_damage = 10.0
	b.placeholder_color = Color(0.55, 0.12, 0.18)
	b.drop_scene = drop
	b.drop_count = 8
	_place(b, parent, ground_pos, Vector2(36.0, 44.0))
	return b


static func _place(e: Enemy, parent: Node, ground_pos: Vector2, size: Vector2) -> Enemy:
	var cs := CollisionShape2D.new()
	var rect := RectangleShape2D.new()
	rect.size = size
	cs.shape = rect
	e.add_child(cs)                 # форма должна быть до add_child врага
	parent.add_child(e)
	e.global_position = ground_pos - Vector2(0.0, size.y * 0.5 + 0.5)
	return e
