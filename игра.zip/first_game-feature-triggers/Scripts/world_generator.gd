class_name WorldGenerator
extends Node2D
## Процедурная генерация уровня: земля, ямы, платформы, монеты.
## Повесь этот скрипт на корневой узел World в world.tscn.
## Рисует поверх слоя TileMapLayers/Environment при запуске игры.

const SRC := 1          # id источника в твоём TileSet
const T := 16           # размер тайла в пикселях
const PIT := -9999      # метка "здесь яма"

# Координаты тайлов в атласе: [слева, середина, справа]
const GROUND_TOP := [Vector2i(6, 0), Vector2i(7, 0), Vector2i(8, 0)]
const GROUND_FILL := [Vector2i(6, 1), Vector2i(7, 1), Vector2i(8, 1)]
const GROUND_BOTTOM := [Vector2i(6, 2), Vector2i(7, 2), Vector2i(8, 2)]
const PLATFORM := [Vector2i(17, 1), Vector2i(18, 1), Vector2i(19, 1)]   # односторонние

@export var generate_on_start: bool = true
@export var seed_value: int = 0              # 0 = каждый раз новая карта
@export var level_width: int = 200           # ширина уровня в тайлах
@export var base_row: int = 18               # строка поверхности на старте
@export var min_row: int = 14                # самая высокая земля (меньше = выше)
@export var max_row: int = 21                # самая низкая земля
@export var bottom_row: int = 34             # нижний край земли
@export_range(0.0, 0.6) var pit_chance: float = 0.25
@export_range(0.0, 1.0) var platform_chance: float = 0.4
@export_range(0.0, 1.0) var coin_chance: float = 0.5
@export var platform_height: int = 3         # на сколько тайлов платформа выше земли
@export var coin_scene: PackedScene
@export var replace_existing_coins: bool = true
@export var with_background: bool = true

@onready var ground_layer: TileMapLayer = $TileMapLayers/Environment
@onready var coins_root: Node2D = $Coins
@onready var player: Player = $Player

var _rng := RandomNumberGenerator.new()
var _surface := PackedInt32Array()
var _platforms: Array[Dictionary] = []
var _kill_y: float = 0.0
var _generated: bool = false


func _ready() -> void:
	if generate_on_start:
		generate()


func _physics_process(_delta: float) -> void:
	if not _generated or player.stats.is_dead:
		return
	# Упал в яму - смерть
	if player.global_position.y > _kill_y:
		player.stats.take_damage(1000000.0, true)


func generate() -> void:
	if seed_value != 0:
		_rng.seed = seed_value
	else:
		_rng.randomize()
	print("[ГЕНЕРАТОР] seed = ", _rng.seed)

	if coin_scene == null and ResourceLoader.exists("res://scenes/coin.tscn"):
		coin_scene = load("res://scenes/coin.tscn")

	_surface = _make_heightmap()
	_platforms.clear()
	ground_layer.clear()
	_build_ground()
	_build_platforms()

	if replace_existing_coins:
		for c in coins_root.get_children():
			c.queue_free()
	_place_coins()

	_place_player()
	_add_boundaries()
	_kill_y = float((bottom_row + 4) * T)
	_generated = true

	if with_background:
		var bg := ProceduralBackground.new()
		bg.ground_y = float(base_row * T)
		bg.seed_value = int(_rng.randi()) + 1
		add_child(bg)


# ---------------------------------------------------------------- РЕЛЬЕФ
func _make_heightmap() -> PackedInt32Array:
	var h := PackedInt32Array()
	h.resize(level_width)
	var row := base_row
	var x := _fill(h, 0, 8, row)                 # ровная стартовая площадка
	var finish_x := level_width - 10

	while x < finish_x:
		if _rng.randf() < pit_chance:
			# Яма шириной 2-4 тайла, после неё земля минимум 4 тайла
			var w := _rng.randi_range(2, 4)
			for k in w:
				if x + k < level_width:
					h[x + k] = PIT
			x += w
			row = clampi(row + _rng.randi_range(-1, 1), min_row, max_row)
			x = _fill(h, x, _rng.randi_range(4, 8), row)
		else:
			# Ступенька не выше 2 тайлов + ровный участок
			row = clampi(row + _rng.randi_range(-2, 2), min_row, max_row)
			x = _fill(h, x, _rng.randi_range(4, 10), row)

	_fill(h, x, level_width - x, row)            # ровный финиш
	return h


func _fill(h: PackedInt32Array, from_x: int, length: int, row: int) -> int:
	var x_end := mini(from_x + length, level_width)
	for cx in range(from_x, x_end):
		h[cx] = row
	return x_end


func _filled(x: int, y: int) -> bool:
	if x < 0 or x >= level_width:
		return false
	return _surface[x] != PIT and y >= _surface[x] and y <= bottom_row


func _pick_tile(x: int, y: int) -> Vector2i:
	var left_open := not _filled(x - 1, y)
	var right_open := not _filled(x + 1, y)
	var col := 1
	if left_open and not right_open:
		col = 0
	elif right_open and not left_open:
		col = 2

	if not _filled(x, y - 1):
		return GROUND_TOP[col]
	if y == bottom_row:
		return GROUND_BOTTOM[col]
	return GROUND_FILL[col]


func _build_ground() -> void:
	for x in level_width:
		if _surface[x] == PIT:
			continue
		for y in range(_surface[x], bottom_row + 1):
			ground_layer.set_cell(Vector2i(x, y), SRC, _pick_tile(x, y))


# ------------------------------------------------------------- ПЛАТФОРМЫ
func _build_platforms() -> void:
	var x := 12
	while x < level_width - 12:
		if _rng.randf() > platform_chance:
			x += _rng.randi_range(3, 6)
			continue

		var length := _rng.randi_range(3, 5)
		var top := 9999
		var low := -9999
		for k in length:
			var s := _surface[x + k]
			if s == PIT:
				continue
			top = mini(top, s)
			low = maxi(low, s)
		if top == 9999:
			top = base_row
			low = base_row

		# Ставим платформу только над почти ровным местом
		if low - top <= 1:
			var row := top - platform_height
			for k in length:
				var atlas: Vector2i = PLATFORM[1]
				if k == 0:
					atlas = PLATFORM[0]
				elif k == length - 1:
					atlas = PLATFORM[2]
				ground_layer.set_cell(Vector2i(x + k, row), SRC, atlas)
			_platforms.append({"x": x, "row": row, "length": length})

		x += length + _rng.randi_range(4, 10)


# ---------------------------------------------------------------- МОНЕТЫ
func _place_coins() -> void:
	if coin_scene == null:
		push_warning("Генератор: не задана сцена монеты (coin_scene)")
		return

	# Дорожки по земле
	var x := 6
	while x < level_width - 6:
		if _surface[x] != PIT and _rng.randf() < coin_chance:
			var length := _rng.randi_range(3, 6)
			for k in length:
				var cx := x + k
				if cx < level_width and _surface[cx] != PIT:
					_spawn_coin(Vector2i(cx, _surface[cx] - 1), Vector2.ZERO)
			x += length + _rng.randi_range(4, 9)
		else:
			x += _rng.randi_range(2, 5)

	# Дуги из монет над ямами
	var col := 0
	while col < level_width:
		if _surface[col] == PIT:
			var start := col
			while col < level_width and _surface[col] == PIT:
				col += 1
			_place_pit_arc(start, col - 1)
		else:
			col += 1

	# Монеты над платформами
	for p in _platforms:
		for k in p["length"]:
			_spawn_coin(Vector2i(p["x"] + k, p["row"] - 1), Vector2.ZERO)


func _place_pit_arc(start: int, last: int) -> void:
	if start < 1 or last >= level_width - 1:
		return
	if _rng.randf() > 0.8:
		return
	var from_x := start - 1
	var to_x := last + 1
	var base_cell := mini(_surface[from_x], _surface[to_x]) - 1
	var span := float(to_x - from_x)
	for cx in range(from_x, to_x + 1):
		var t := float(cx - from_x) / span
		var lift := sin(PI * t) * 2.5 * T
		_spawn_coin(Vector2i(cx, base_cell), Vector2(0.0, -lift))


func _spawn_coin(cell: Vector2i, offset: Vector2) -> void:
	var coin := coin_scene.instantiate() as Node2D
	coins_root.add_child(coin)
	coin.global_position = ground_layer.to_global(ground_layer.map_to_local(cell)) + offset


# ------------------------------------------------- ИГРОК И ГРАНИЦЫ УРОВНЯ
func _place_player() -> void:
	var cell := Vector2i(3, _surface[3] - 2)
	player.global_position = ground_layer.to_global(ground_layer.map_to_local(cell))
	player.velocity = Vector2.ZERO


func _add_boundaries() -> void:
	# Невидимые стены слева и справа
	for side in [-1, 1]:
		var wall := StaticBody2D.new()
		var shape := CollisionShape2D.new()
		var rect := RectangleShape2D.new()
		rect.size = Vector2(T, 4000.0)
		shape.shape = rect
		wall.add_child(shape)
		if side == -1:
			wall.position = Vector2(-T * 0.5, 0.0)
		else:
			wall.position = Vector2(level_width * T + T * 0.5, 0.0)
		add_child(wall)

	# Камера не выходит за края уровня
	var cam := player.get_node_or_null("Camera") as Camera2D
	if cam:
		cam.limit_left = 0
		cam.limit_right = level_width * T
		cam.limit_bottom = (bottom_row + 1) * T
