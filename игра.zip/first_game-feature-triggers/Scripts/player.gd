class_name Player
extends CharacterBody2D

@export var SPEED: float = 300.0
@export var SPRINT_SPEED: float = 450.0
@export var SPRINT_COST: float = 20.0   # выносливость в секунду
@export var JUMP_COST: float = 10.0     # выносливость за прыжок (0 = бесплатно)
@export var JUMP_VELOCITY: float = -400.0
@export var animated_sprite: AnimatedSprite2D

@onready var stats: Stats = $Stats

enum State {
	IDLE,
	RUN,
	JUMP,
	FALL
}

var current_state: State = State.IDLE

var gravity: float = ProjectSettings.get_setting("physics/2d/default_gravity")
var coins: int = 0
var keys: int = 0


func _ready() -> void:
	stats.died.connect(_on_died)


func _physics_process(delta: float) -> void:
	apply_gravity(delta)
	handle_jump()

	var direction: float = Input.get_axis("move_left", "move_right")
	handle_movement(direction, delta)

	move_and_slide()

	handle_flip(direction)
	update_state(direction)
	play_animation()


func apply_gravity(delta: float) -> void:
	if not is_on_floor():
		velocity.y += gravity * delta


func handle_jump() -> void:
	if Input.is_action_just_pressed("jump") and is_on_floor():
		# Прыжок тратит выносливость; если её не хватает - не прыгаем
		if stats.use_stamina(JUMP_COST):
			velocity.y = JUMP_VELOCITY


func handle_movement(direction: float, delta: float) -> void:
	var speed: float = SPEED
	# Бег на Shift: тратит выносливость, пока она есть
	if Input.is_key_pressed(KEY_SHIFT) and direction != 0.0 and stats.use_stamina(SPRINT_COST * delta):
		speed = SPRINT_SPEED
	velocity.x = direction * speed


func handle_flip(direction: float) -> void:
	if direction > 0.0:
		animated_sprite.flip_h = false
	elif direction < 0.0:
		animated_sprite.flip_h = true


func update_state(direction: float) -> void:
	if is_on_floor():
		if direction == 0.0:
			current_state = State.IDLE
		else:
			current_state = State.RUN
	else:
		if velocity.y < 0.0:
			current_state = State.JUMP
		else:
			current_state = State.FALL


func play_animation() -> void:
	match current_state:
		State.IDLE:
			animated_sprite.play("idle")
		State.RUN:
			animated_sprite.play("run")
		State.JUMP:
			animated_sprite.play("jump")
		State.FALL:
			animated_sprite.play("fall")


func _on_died() -> void:
	# Простая смерть: перезапуск уровня
	get_tree().reload_current_scene.call_deferred()


# ---------- ВРЕМЕННАЯ ОТЛАДКА (потом удалить) ----------
func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_K:
			stats.take_damage(10.0)
			print("HP: ", stats.health, "/", stats.max_health, "  Броня: ", stats.armor)
		elif event.keycode == KEY_H:
			stats.heal(10.0)
			print("HP: ", stats.health, "/", stats.max_health)
