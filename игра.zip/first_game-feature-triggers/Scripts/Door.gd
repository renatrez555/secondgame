class_name Door
extends StaticBody2D
## Дверь-преграда. Пока закрыта, блокирует проход.
## requires_key = false -> открывается по E (или сама, если auto_open)
## requires_key = true  -> открывается, только если у игрока есть ключ

@export var requires_key: bool = false   # нужен ли ключ
@export var consume_key: bool = true     # тратить ли ключ при открытии
@export var auto_open: bool = false      # открывать при приближении, без E

@onready var visual: CanvasItem = $Sprite2D
@onready var zone: Area2D = $InteractZone

var is_open: bool = false
var _player: Player = null


func _ready() -> void:
	zone.collision_layer = 0
	zone.collision_mask = 0xFFFFFFFF
	zone.monitoring = true
	zone.body_entered.connect(_on_zone_entered)
	zone.body_exited.connect(_on_zone_exited)


func _on_zone_entered(body: Node2D) -> void:
	if body is Player:
		_player = body
		if auto_open:
			try_open()


func _on_zone_exited(body: Node2D) -> void:
	if body == _player:
		_player = null


func _unhandled_input(event: InputEvent) -> void:
	if is_open or auto_open or _player == null:
		return
	if event is InputEventKey and event.pressed and not event.echo and event.keycode == KEY_E:
		try_open()


func try_open() -> void:
	if is_open or _player == null:
		return
	if requires_key:
		if _player.keys <= 0:
			print("[ДВЕРЬ] Заперта. Нужен ключ.")
			return
		if consume_key:
			_player.keys -= 1
	open()


func open() -> void:
	is_open = true
	set_deferred("collision_layer", 0)   # дверь больше не блокирует игрока
	print("[ДВЕРЬ] открыта")
	var tween := create_tween()
	tween.tween_property(visual, "modulate:a", 0.0, 0.3)
	tween.tween_callback(visual.hide)
