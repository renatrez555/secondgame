class_name ProceduralBackground
extends ParallaxBackground
## Бесконечный живой фон без повторов и без заготовок.
## Из seed генерируется ВСЁ: палитра неба и растительности, число и форма слоёв холмов,
## виды деревьев, форма облаков, размер солнца и луны, кратеры на луне.
## Холмы строятся из шума кусками перед камерой и удаляются позади.
## Создаётся из world_generator.gd.

@export var ground_y: float = 288.0          # высота поверхности земли в мире (px)
@export var seed_value: int = 0
@export var day_length: float = 120.0        # секунд на сутки (0 = время не идёт)
@export_range(0.0, 1.0) var start_time: float = 0.4   # 0 полночь, 0.25 рассвет, 0.5 полдень, 0.75 закат
@export var cloud_count: int = 10
@export var cloud_drift: float = 8.0
@export var bird_count: int = 8
@export var firefly_count: int = 45
@export var tree_density: int = 5            # макс. деревьев на кусок фона
@export var star_count: int = 80
@export var margin_views: float = 1.2        # запас генерации в ширинах экрана

const CHUNK_W := 480.0                       # ширина куска холмов (px)
const CLOUD_MX := 0.12
const BIRD_MX := 0.30
const FIREFLY_MX := 0.80

var _rng := RandomNumberGenerator.new()
var _world_seed: int = 0
var _time: float = 0.0
var _tod: float = 0.4        # время суток 0..1
var _day: float = 1.0        # 0 = ночь, 1 = день
var _warm: float = 0.0       # сила рассвета/заката

# Палитра (создаётся в _make_palette)
var _sky_hue: float = 0.58
var _foliage_hue: float = 0.3
var _day_top: Color
var _day_bottom: Color
var _night_top: Color
var _night_bottom: Color
var _warm_top: Color
var _warm_bottom: Color
var _cloud_color: Color
var _crown_color: Color
var _trunk_color: Color
var _fly_color: Color
var _sun_hue: float = 0.1
var _sun_r: float = 22.0
var _moon_r: float = 18.0
var _moon_craters: Array[Vector3] = []
var _forest_bias: float = 0.4

var _sky_gradient: Gradient
var _sky_painter: Painter
var _tint_layers: Array[ParallaxLayer] = []
var _animated: Array[Painter] = []
var _hill_layers: Array[Dictionary] = []
var _forest_noise: FastNoiseLite

var _stars: Array[Dictionary] = []
var _clouds: Array[Dictionary] = []
var _birds: Array[Dictionary] = []
var _fireflies: Array[Dictionary] = []


func _ready() -> void:
	if seed_value != 0:
		_rng.seed = seed_value
	else:
		_rng.randomize()
	_world_seed = int(_rng.seed)

	_make_palette()
	RenderingServer.set_default_clear_color(_day_bottom)
	_build_sky()
	_build_parallax()
	_update_cycle(0.0)


func _process(delta: float) -> void:
	_update_cycle(delta)
	_update_particles(delta)
	for hl in _hill_layers:
		_update_chunks(hl)
	_sky_painter.queue_redraw()
	for p in _animated:
		p.queue_redraw()


# ------------------------------------------------------------------ ПАЛИТРА
# Все цвета выводятся из двух оттенков: неба и растительности
func _make_palette() -> void:
	# Небо: чаще голубое, иногда любой оттенок
	if _rng.randf() < 0.7:
		_sky_hue = _rng.randf_range(0.52, 0.62)
	else:
		_sky_hue = _rng.randf()
	# Растительность: чаще зелёная, иногда осенняя, бирюзовая, фиолетовая
	if _rng.randf() < 0.7:
		_foliage_hue = _rng.randf_range(0.22, 0.40)
	else:
		_foliage_hue = _rng.randf()

	_day_top = Color.from_hsv(_sky_hue, _rng.randf_range(0.45, 0.70), _rng.randf_range(0.85, 0.98))
	_day_bottom = Color.from_hsv(fposmod(_sky_hue + _rng.randf_range(-0.03, 0.03), 1.0),
			_rng.randf_range(0.10, 0.30), 1.0)
	_night_top = Color.from_hsv(fposmod(_sky_hue + 0.03, 1.0), 0.8, _rng.randf_range(0.08, 0.16))
	_night_bottom = Color.from_hsv(fposmod(_sky_hue + 0.05, 1.0), 0.65, _rng.randf_range(0.24, 0.34))
	_warm_bottom = Color.from_hsv(_rng.randf_range(0.0, 0.10), _rng.randf_range(0.55, 0.80), 1.0)
	_warm_top = Color.from_hsv(_rng.randf_range(0.62, 0.80), _rng.randf_range(0.40, 0.60),
			_rng.randf_range(0.55, 0.70))

	_cloud_color = Color.from_hsv(_sky_hue, 0.05, 1.0, 0.85)
	_crown_color = Color.from_hsv(fposmod(_foliage_hue + _rng.randf_range(-0.04, 0.04), 1.0), 0.55, 0.38)
	_trunk_color = Color.from_hsv(_rng.randf_range(0.05, 0.10), 0.5, 0.3)
	_fly_color = Color.from_hsv(_rng.randf_range(0.12, 0.30), 0.55, 1.0)

	_sun_hue = _rng.randf_range(0.08, 0.14)
	_sun_r = _rng.randf_range(16.0, 32.0)
	_moon_r = _rng.randf_range(14.0, 24.0)
	for i in _rng.randi_range(2, 5):
		_moon_craters.append(Vector3(_rng.randf_range(-0.5, 0.5), _rng.randf_range(-0.5, 0.5),
				_rng.randf_range(0.10, 0.25)))

	_forest_bias = _rng.randf_range(0.3, 0.5)


# --------------------------------------------- ВИДИМАЯ ОБЛАСТЬ СЛОЯ (по X)
# Возвращает диапазон координат внутри слоя, который нужно заполнить.
func _range_for(mx: float) -> Vector2:
	var cx := 0.0
	var zoom := 1.0
	var cam := get_viewport().get_camera_2d()
	if cam:
		cx = cam.get_screen_center_position().x
		zoom = cam.zoom.x
	var view_w := get_viewport().get_visible_rect().size.x / maxf(zoom, 0.01)
	var center := mx * cx + (1.0 - mx) * view_w * 0.5
	return Vector2(center - view_w * margin_views, center + view_w * margin_views)


# ------------------------------------------------------------ СМЕНА ДНЯ И НОЧИ
func _update_cycle(delta: float) -> void:
	_time += delta
	if day_length > 0.0:
		_tod = fposmod(start_time + _time / day_length, 1.0)
	else:
		_tod = start_time

	var s := sin((_tod - 0.25) * TAU)             # 1 в полдень, -1 в полночь
	_day = smoothstep(-0.25, 0.35, s)
	_warm = clampf(1.0 - absf(s) * 1.8, 0.0, 1.0)

	var top := _night_top.lerp(_day_top, _day).lerp(_warm_top, _warm * 0.7)
	var bottom := _night_bottom.lerp(_day_bottom, _day).lerp(_warm_bottom, _warm * 0.85)
	_sky_gradient.set_color(0, top)
	_sky_gradient.set_color(1, bottom)

	# Холмы и облака темнеют ночью и теплеют на закате
	var tint := Color(0.36, 0.40, 0.62).lerp(Color.WHITE, _day)
	tint = tint.lerp(Color(1.0, 0.82, 0.70), _warm * 0.5)
	for layer in _tint_layers:
		layer.modulate = tint


# ------------------------------------------------------------------- НЕБО
func _build_sky() -> void:
	# Градиент неба на весь экран
	var sky_layer := CanvasLayer.new()
	sky_layer.layer = -120
	add_child(sky_layer)

	_sky_gradient = Gradient.new()
	_sky_gradient.offsets = PackedFloat32Array([0.0, 1.0])
	_sky_gradient.colors = PackedColorArray([_day_top, _day_bottom])

	var tex := GradientTexture2D.new()
	tex.gradient = _sky_gradient
	tex.fill_from = Vector2(0.0, 0.0)
	tex.fill_to = Vector2(0.0, 1.0)
	tex.width = 8
	tex.height = 256

	var rect := TextureRect.new()
	rect.texture = tex
	rect.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	rect.stretch_mode = TextureRect.STRETCH_SCALE
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	sky_layer.add_child(rect)
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	# Солнце, луна и звёзды (рисуются в координатах экрана)
	var celestial := CanvasLayer.new()
	celestial.layer = -110
	add_child(celestial)

	for i in star_count:
		_stars.append({
			"p": Vector2(_rng.randf(), _rng.randf() * 0.6),
			"ph": _rng.randf() * TAU,
			"s": _rng.randf_range(0.8, 1.8),
		})

	_sky_painter = Painter.new()
	_sky_painter.paint = _paint_sky_objects
	celestial.add_child(_sky_painter)


func _arc_pos(angle: float, size: Vector2) -> Vector2:
	return Vector2(size.x * (0.5 - cos(angle) * 0.42), size.y * (0.72 - sin(angle) * 0.62))


func _paint_sky_objects(canvas: Node2D) -> void:
	var size := get_viewport().get_visible_rect().size
	var night := 1.0 - _day

	# Звёзды мерцают
	if night > 0.02:
		var star_col := Color.from_hsv(_sky_hue, 0.12, 1.0)
		for st in _stars:
			var p: Vector2 = st["p"]
			var twinkle := 0.55 + 0.45 * sin(_time * 2.0 + float(st["ph"]))
			canvas.draw_circle(Vector2(p.x * size.x, p.y * size.y), float(st["s"]),
					Color(star_col, night * twinkle))

	# Солнце
	var sun_a := (_tod - 0.25) / 0.5 * PI
	if sun_a > -0.15 and sun_a < PI + 0.15:
		var sp := _arc_pos(sun_a, size)
		var elev := clampf(sin(sun_a), 0.0, 1.0)
		var col := Color(1.0, 0.55, 0.25).lerp(Color.from_hsv(_sun_hue, 0.15, 1.0), elev)
		canvas.draw_circle(sp, _sun_r * 2.1, Color(col, 0.12))
		canvas.draw_circle(sp, _sun_r * 1.45, Color(col, 0.25))
		canvas.draw_circle(sp, _sun_r, col)

	# Луна
	var moon_a := (fposmod(_tod + 0.5, 1.0) - 0.25) / 0.5 * PI
	if moon_a > -0.15 and moon_a < PI + 0.15:
		var mp := _arc_pos(moon_a, size)
		canvas.draw_circle(mp, _moon_r * 1.9, Color(0.8, 0.85, 1.0, 0.10))
		canvas.draw_circle(mp, _moon_r, Color(0.93, 0.95, 1.0))
		for cr in _moon_craters:
			canvas.draw_circle(mp + Vector2(cr.x, cr.y) * _moon_r, cr.z * _moon_r, Color(0.80, 0.84, 0.93))


# --------------------------------------------------------------- ПАРАЛЛАКС
func _build_parallax() -> void:
	_forest_noise = FastNoiseLite.new()
	_forest_noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	_forest_noise.seed = _rng.randi()
	_forest_noise.frequency = _rng.randf_range(0.0005, 0.0015)

	# Облака
	var cloud_layer := _add_layer(CLOUD_MX, true)
	var rc := _range_for(CLOUD_MX)
	for i in cloud_count:
		var c := {"x": 0.0, "y": 0.0, "blobs": []}
		_respawn_cloud(c, rc, true)
		_clouds.append(c)
	_add_painter(cloud_layer, _clouds_painter(), true)

	# Холмы: число слоёв и их параметры случайны, дальние бледнее и выше
	var n := _rng.randi_range(3, 5)
	var birds_after := _rng.randi_range(0, n - 2)
	for i in n:
		var t := float(i) / float(maxi(n - 1, 1))      # 0 = дальний, 1 = ближний
		var ground := Color.from_hsv(fposmod(_foliage_hue + _rng.randf_range(-0.03, 0.03), 1.0),
				lerpf(0.25, 0.55, t), lerpf(0.85, 0.48, t))
		_add_hill_layer({
			"color": _day_bottom.lerp(ground, lerpf(0.35, 1.0, t)),
			"base": ground_y + lerpf(-30.0, 30.0, t) + _rng.randf_range(-8.0, 8.0),
			"amp": lerpf(_rng.randf_range(90.0, 140.0), _rng.randf_range(40.0, 70.0), t),
			"freq": lerpf(_rng.randf_range(0.0020, 0.0035), _rng.randf_range(0.006, 0.010), t),
			"mx": maxf(lerpf(0.15, 0.6, t) + _rng.randf_range(-0.03, 0.03), 0.05),
			"trees": i == n - 1,
		})
		if i == birds_after:
			_add_birds()

	# Светлячки (ночью)
	var fly_layer := _add_layer(FIREFLY_MX, false)
	var rf := _range_for(FIREFLY_MX)
	for i in firefly_count:
		var f := {"x": 0.0, "y": 0.0, "ph": 0.0}
		_respawn_firefly(f, rf, true)
		_fireflies.append(f)
	_add_painter(fly_layer, _fireflies_painter(), true)


func _add_birds() -> void:
	var layer := _add_layer(BIRD_MX, false)
	var rb := _range_for(BIRD_MX)
	for i in bird_count:
		var b := {"x": 0.0, "y": 0.0, "v": 0.0, "f": 0.0, "s": 0.0, "ph": 0.0}
		_respawn_bird(b, rb, true)
		_birds.append(b)
	_add_painter(layer, _birds_painter(), true)


func _add_layer(motion_x: float, tinted: bool) -> ParallaxLayer:
	var layer := ParallaxLayer.new()
	# По Y слой привязан к миру (1.0), по X двигается медленнее камеры
	layer.motion_scale = Vector2(motion_x, 1.0)
	add_child(layer)
	if tinted:
		_tint_layers.append(layer)
	return layer


func _add_painter(layer: ParallaxLayer, fn: Callable, animated: bool) -> Painter:
	var p := Painter.new()
	p.paint = fn
	layer.add_child(p)
	if animated:
		_animated.append(p)
	return p


# ------------------------------------------------------- ХОЛМЫ ПО КУСКАМ
func _add_hill_layer(def: Dictionary) -> void:
	def["layer"] = _add_layer(float(def["mx"]), true)
	var noise := FastNoiseLite.new()
	noise.noise_type = FastNoiseLite.TYPE_SIMPLEX_SMOOTH
	noise.seed = _rng.randi()
	noise.frequency = float(def["freq"])
	noise.fractal_octaves = 2
	def["noise"] = noise
	def["chunks"] = {}
	_hill_layers.append(def)
	_update_chunks(def)


# Высота холма в точке x (шум, поэтому рельеф никогда не повторяется)
func _hill_h(hl: Dictionary, x: float) -> float:
	var noise: FastNoiseLite = hl["noise"]
	return float(hl["amp"]) * clampf(0.5 + 0.7 * noise.get_noise_1d(x), 0.0, 1.0)


# Создаёт куски перед камерой и удаляет те, что остались далеко позади
func _update_chunks(hl: Dictionary) -> void:
	var r := _range_for(float(hl["mx"]))
	var lo := int(floor(r.x / CHUNK_W))
	var hi := int(floor(r.y / CHUNK_W))
	var chunks: Dictionary = hl["chunks"]

	for idx in range(lo, hi + 1):
		if not chunks.has(idx):
			chunks[idx] = _make_chunk(hl, idx)

	for idx in chunks.keys():
		if idx < lo - 1 or idx > hi + 1:
			for node in chunks[idx]:
				_animated.erase(node)
				node.queue_free()
			chunks.erase(idx)


func _make_chunk(hl: Dictionary, idx: int) -> Array:
	var layer: ParallaxLayer = hl["layer"]
	var nodes: Array = []

	var hills := _add_painter(layer, _hills_painter(hl, idx), false)
	hills.position = Vector2(idx * CHUNK_W, 0.0)
	nodes.append(hills)

	if hl["trees"]:
		var trees := _add_painter(layer, _trees_painter(hl, idx, _make_trees(idx)), true)
		trees.position = Vector2(idx * CHUNK_W, 0.0)
		nodes.append(trees)
	return nodes


func _hills_painter(hl: Dictionary, idx: int) -> Callable:
	return func(canvas: Node2D) -> void:
		var x0 := float(idx) * CHUNK_W
		var base := float(hl["base"])
		var pts := PackedVector2Array()
		var step := 16.0
		var n := int(CHUNK_W / step)
		# Заходим на 16 px в соседний кусок, чтобы не было щелей
		for i in range(n + 2):
			var lx := i * step
			pts.append(Vector2(lx, base - _hill_h(hl, x0 + lx)))
		pts.append(Vector2((n + 1) * step, base + 2000.0))
		pts.append(Vector2(0.0, base + 2000.0))
		canvas.draw_colored_polygon(pts, hl["color"])


# ---------------------------------------------------------------- ДЕРЕВЬЯ
# У каждого дерева свои случайные параметры: число ярусов, форма яруса
# (от ромба до эллипса), ширина кроны, высота ствола, наклон, оттенок.
# Один и тот же номер куска даёт одни и те же деревья, поэтому лес не "прыгает".
func _make_trees(idx: int) -> Array:
	var r := RandomNumberGenerator.new()
	r.seed = hash([_world_seed, idx, 7])
	var forest := 0.5 + 0.5 * _forest_noise.get_noise_1d((float(idx) + 0.5) * CHUNK_W) * 1.4
	var count := int(round(clampf((forest - _forest_bias) * 2.5, 0.0, 1.0) * tree_density))
	var out: Array = []
	for i in count:
		out.append({
			"x": r.randf_range(20.0, CHUNK_W - 20.0),
			"h": r.randf_range(30.0, 70.0),
			"tiers": r.randi_range(1, 4),
			"n": r.randf_range(1.0, 2.4),
			"wr": r.randf_range(0.18, 0.42),
			"tr": r.randf_range(0.12, 0.38),
			"lean": r.randf_range(-0.15, 0.15),
			"shade": r.randf_range(0.8, 1.2),
			"ph": r.randf() * TAU,
		})
	return out


func _trees_painter(hl: Dictionary, idx: int, trees: Array) -> Callable:
	var x0 := float(idx) * CHUNK_W
	return func(canvas: Node2D) -> void:
		for t in trees:
			var lx: float = t["x"]
			var wx := x0 + lx
			var base := Vector2(lx, float(hl["base"]) - _hill_h(hl, wx) + 6.0)
			# Ветер качает верхушки
			var sway := sin(_time * 1.4 + float(t["ph"]) + wx * 0.01) * 2.5 + sin(_time * 0.6 + wx) * 1.0
			_draw_tree(canvas, base, t, sway)


func _draw_tree(canvas: Node2D, base: Vector2, t: Dictionary, sway: float) -> void:
	var h: float = t["h"]
	var tiers: int = t["tiers"]
	var shade: float = t["shade"]
	var trunk_h := h * float(t["tr"])
	var col := Color(clampf(_crown_color.r * shade, 0.0, 1.0), clampf(_crown_color.g * shade, 0.0, 1.0),
			clampf(_crown_color.b * shade, 0.0, 1.0))

	var trunk_w := maxf(h * 0.07, 3.0)
	canvas.draw_rect(Rect2(base.x - trunk_w * 0.5, base.y - trunk_h, trunk_w, trunk_h), _trunk_color)

	# Крона: tiers ярусов, каждый - суперэллипс (n=1 ромб ... n=2 эллипс)
	var crown_bottom := base.y - trunk_h * 0.7
	var crown_h := h - trunk_h * 0.7
	var tier_h := crown_h / (1.0 + 0.55 * float(tiers - 1))
	var crown_w := h * float(t["wr"])
	var expo := 2.0 / float(t["n"])

	for i in tiers:
		var k := float(i) / float(tiers)
		var cy := crown_bottom - float(i) * 0.55 * tier_h - tier_h * 0.5
		var w := crown_w * (1.0 - 0.6 * k)
		var cx := base.x + sway * (0.3 + 0.7 * k) + float(t["lean"]) * h * k
		var pts := PackedVector2Array()
		for j in 14:
			var a := TAU * float(j) / 14.0
			var ca := cos(a)
			var sa := sin(a)
			pts.append(Vector2(cx + w * signf(ca) * pow(absf(ca), expo),
					cy + tier_h * 0.5 * signf(sa) * pow(absf(sa), expo)))
		canvas.draw_colored_polygon(pts, col)


# ------------------------------------- ЧАСТИЦЫ: ОБЛАКА, ПТИЦЫ, СВЕТЛЯЧКИ
# Уходят за камеру - появляются впереди, поэтому фон никогда не заканчивается
func _respawn_cloud(c: Dictionary, r: Vector2, initial: bool) -> void:
	if initial:
		c["x"] = _rng.randf_range(r.x, r.y)
	else:
		c["x"] = r.y + _rng.randf_range(0.0, 200.0)
	c["y"] = ground_y - _rng.randf_range(110.0, 230.0)

	# Форма облака каждый раз новая: случайное число "клубов" разного размера
	var cr := _rng.randf_range(14.0, 30.0)
	var span := cr * _rng.randf_range(2.2, 4.5)
	var count := _rng.randi_range(3, 6)
	var blobs: Array[Vector3] = []
	for i in count:
		var bx := -span * 0.5 + span * (float(i) + _rng.randf() * 0.6) / float(count)
		var edge := clampf(1.0 - absf(bx) / (span * 0.5), 0.0, 1.0)
		var br := cr * lerpf(0.45, 1.0, edge) * _rng.randf_range(0.75, 1.1)
		blobs.append(Vector3(bx, -br * _rng.randf_range(0.0, 0.5), br))
	c["blobs"] = blobs


func _respawn_bird(b: Dictionary, r: Vector2, initial: bool) -> void:
	if initial:
		b["x"] = _rng.randf_range(r.x, r.y)
	else:
		b["x"] = r.y + _rng.randf_range(0.0, 150.0)
	b["y"] = ground_y - _rng.randf_range(120.0, 230.0)
	b["v"] = _rng.randf_range(25.0, 55.0)
	b["f"] = _rng.randf_range(6.0, 9.0)
	b["s"] = _rng.randf_range(6.0, 10.0)
	b["ph"] = _rng.randf() * TAU


func _respawn_firefly(f: Dictionary, r: Vector2, initial: bool) -> void:
	if initial:
		f["x"] = _rng.randf_range(r.x, r.y)
	else:
		f["x"] = r.y + _rng.randf_range(0.0, 300.0)
	f["y"] = ground_y - _rng.randf_range(5.0, 80.0)
	f["ph"] = _rng.randf() * TAU


func _update_particles(delta: float) -> void:
	var rc := _range_for(CLOUD_MX)
	for c in _clouds:
		c["x"] = float(c["x"]) - cloud_drift * delta
		if float(c["x"]) < rc.x - 150.0:
			_respawn_cloud(c, rc, false)
		elif float(c["x"]) > rc.y + 400.0:
			c["x"] = rc.x - _rng.randf_range(0.0, 150.0)

	var rb := _range_for(BIRD_MX)
	for b in _birds:
		b["x"] = float(b["x"]) + float(b["v"]) * delta
		if float(b["x"]) < rb.x - 200.0:
			_respawn_bird(b, rb, false)
		elif float(b["x"]) > rb.y + 300.0:
			b["x"] = rb.x - _rng.randf_range(0.0, 150.0)

	var rf := _range_for(FIREFLY_MX)
	for f in _fireflies:
		if float(f["x"]) < rf.x - 100.0:
			_respawn_firefly(f, rf, false)
		elif float(f["x"]) > rf.y + 400.0:
			f["x"] = rf.x - _rng.randf_range(0.0, 300.0)


func _clouds_painter() -> Callable:
	return func(canvas: Node2D) -> void:
		for c in _clouds:
			var p := Vector2(c["x"], c["y"])
			for bl in c["blobs"]:
				var blob: Vector3 = bl
				canvas.draw_circle(p + Vector2(blob.x, blob.y), blob.z, _cloud_color)


func _birds_painter() -> Callable:
	return func(canvas: Node2D) -> void:
		var vis := clampf((_day - 0.25) * 2.0, 0.0, 1.0)
		if vis <= 0.01:
			return
		for b in _birds:
			var x := float(b["x"])
			var y := float(b["y"]) + sin(_time * 0.8 + float(b["ph"])) * 6.0
			var flap := sin(_time * float(b["f"]) + float(b["ph"]))
			var s := float(b["s"])
			var col := Color(0.12, 0.14, 0.20, 0.75 * vis)
			canvas.draw_polyline(PackedVector2Array([
				Vector2(x - s, y - s * 0.55 * flap),
				Vector2(x, y),
				Vector2(x + s, y - s * 0.55 * flap),
			]), col, 1.6)


func _fireflies_painter() -> Callable:
	return func(canvas: Node2D) -> void:
		var night := 1.0 - _day
		if night < 0.05:
			return
		for f in _fireflies:
			var ph := float(f["ph"])
			var p := Vector2(
				float(f["x"]) + sin(_time * 0.7 + ph) * 14.0,
				float(f["y"]) + cos(_time * 0.9 + ph * 1.3) * 8.0)
			var glow := night * (0.5 + 0.5 * sin(_time * 3.0 + ph * 2.0))
			canvas.draw_circle(p, 5.0, Color(_fly_color, glow * 0.18))
			canvas.draw_circle(p, 1.8, Color(_fly_color.lightened(0.3), glow))


# Узел, который вызывает рисующую функцию в своём _draw()
class Painter extends Node2D:
	var paint: Callable

	func _draw() -> void:
		paint.call(self)
